<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="email"], input[type="password"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        .btn {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            width: 100%;
        }
        .loading {
            display: none;
            text-align: center;
            margin-top: 10px;
        }
        .error {
            color: red;
            font-size: 12px;
            margin-top: 5px;
        }
        .success {
            color: green;
            font-size: 12px;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <h2>Customer Login</h2>
        <form id="loginForm">
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" required>
                <div class="error" id="email_error"></div>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
                <div class="error" id="password_error"></div>
            </div>
            
            <button type="submit" class="btn" id="submitBtn">Login</button>
            
            <div class="loading" id="loading">
                Processing login...
            </div>
            
            <div class="error" id="general_error"></div>
            <div class="success" id="general_success"></div>
        </form>
        
        <div style="text-align: center; margin-top: 15px;">
            <a href="register.php">Don't have an account? Register here</a>
        </div>
        
        <div style="text-align: center; margin-top: 15px;">
            <a href="index.php">← Back to Home</a>
        </div>
    
    <script src="login.js"></script>
</body>
</html>
